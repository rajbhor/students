--
-- Database : du
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `blood_groups`
--
DROP TABLE  IF EXISTS `blood_groups`;
CREATE TABLE `blood_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `blood_groups`  VALUES ( "1","A+");
INSERT INTO `blood_groups`  VALUES ( "2","A-");
INSERT INTO `blood_groups`  VALUES ( "3","B+");
INSERT INTO `blood_groups`  VALUES ( "4","B-");
INSERT INTO `blood_groups`  VALUES ( "5","O+");
INSERT INTO `blood_groups`  VALUES ( "6","O-");
INSERT INTO `blood_groups`  VALUES ( "7","AB+");
INSERT INTO `blood_groups`  VALUES ( "8","AB-");
INSERT INTO `blood_groups`  VALUES ( "9","Unknown");


--
-- Tabel structure for table `castate_dump`
--
DROP TABLE  IF EXISTS `castate_dump`;
CREATE TABLE `castate_dump` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `castate_dump`  VALUES ( "1","Assam");
INSERT INTO `castate_dump`  VALUES ( "3","New Delhi");
INSERT INTO `castate_dump`  VALUES ( "4","Maharashtra");
INSERT INTO `castate_dump`  VALUES ( "11","Meghalaya");
INSERT INTO `castate_dump`  VALUES ( "10","Manipur");
INSERT INTO `castate_dump`  VALUES ( "7","West Bengal");
INSERT INTO `castate_dump`  VALUES ( "8","Arunachal Pradesh");
INSERT INTO `castate_dump`  VALUES ( "9","Tamil Nadu");


--
-- Tabel structure for table `caste`
--
DROP TABLE  IF EXISTS `caste`;
CREATE TABLE `caste` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caste_name` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `caste`  VALUES ( "1","General");
INSERT INTO `caste`  VALUES ( "2","SC");
INSERT INTO `caste`  VALUES ( "3","ST(P)");
INSERT INTO `caste`  VALUES ( "4","OBC");
INSERT INTO `caste`  VALUES ( "5","MOBC");
INSERT INTO `caste`  VALUES ( "6","ST(H)");
INSERT INTO `caste`  VALUES ( "7","Others");


--
-- Tabel structure for table `center`
--
DROP TABLE  IF EXISTS `center`;
CREATE TABLE `center` (
  `center_code` int(11) NOT NULL AUTO_INCREMENT,
  `center_name` varchar(200) NOT NULL,
  `sf_code` varchar(40) NOT NULL,
  PRIMARY KEY (`center_code`),
  UNIQUE KEY `center_name` (`center_name`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `center`  VALUES ( "1","Centre for Atmospheric Studies","CAS");
INSERT INTO `center`  VALUES ( "2","Centre for Studies in Behavioural Sciences","CSBS");
INSERT INTO `center`  VALUES ( "3","Centre for Bioinformatics Studies","CBS");
INSERT INTO `center`  VALUES ( "4","Centre for Studies in Biotechnology","CSB");
INSERT INTO `center`  VALUES ( "5","Centre for Computer Studies","CCS");
INSERT INTO `center`  VALUES ( "6","Centre for studies in Geography","CSG");
INSERT INTO `center`  VALUES ( "7","Centre for Studies in Journalism and Mass Communication","CSJMC");
INSERT INTO `center`  VALUES ( "8","Centre for Juridical Studies","CJS");
INSERT INTO `center`  VALUES ( "9","Centre for Studies in Languages","CSL");
INSERT INTO `center`  VALUES ( "10","Centre for Library and Information Science Studies","CLIB");
INSERT INTO `center`  VALUES ( "11","Centre for Management Studies","CMS");
INSERT INTO `center`  VALUES ( "12","Centre for Nanoscience and Composite Materials","CNano");
INSERT INTO `center`  VALUES ( "13","Dr. Bhupen Hazarika Centre For Studies In Performing Arts","BHUPEN");
INSERT INTO `center`  VALUES ( "14","Centre for Studies in Philosophy","CSP");
INSERT INTO `center`  VALUES ( "15","Centre for Studies in Physical Education and Sports","CSPE");
INSERT INTO `center`  VALUES ( "16","Centre for Studies in Rural Development","CSRD");
INSERT INTO `center`  VALUES ( "17","Centre for Social Work Studies","CSWS");
INSERT INTO `center`  VALUES ( "18","Centre For Tea And Agro Studies","CTA");
INSERT INTO `center`  VALUES ( "19","Centre for Womens Studies","CWS");
INSERT INTO `center`  VALUES ( "22","Institute Of Science And Technology (DUIET)","DUIET");


--
-- Tabel structure for table `center_course`
--
DROP TABLE  IF EXISTS `center_course`;
CREATE TABLE `center_course` (
  `cc_code` int(11) NOT NULL AUTO_INCREMENT,
  `cc_name` varchar(500) NOT NULL,
  `center_code` int(11) NOT NULL,
  PRIMARY KEY (`cc_code`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=latin1 COMMENT='not used till now';

INSERT INTO `center_course`  VALUES ( "1","Advanced Post Graduate Diploma in Atmospheric Physics (APGDAP)","1");
INSERT INTO `center_course`  VALUES ( "2","M.A. in Applied Psychology","2");
INSERT INTO `center_course`  VALUES ( "3","P.G. Diploma in Applied Psychology","2");
INSERT INTO `center_course`  VALUES ( "4","M.Sc. in Bioinformatics","3");
INSERT INTO `center_course`  VALUES ( "5","Ph.D.","3");
INSERT INTO `center_course`  VALUES ( "6","M.Sc. in Biotechnology","4");
INSERT INTO `center_course`  VALUES ( "7","Ph.D.","4");
INSERT INTO `center_course`  VALUES ( "8","M.C.A.","5");
INSERT INTO `center_course`  VALUES ( "9","B.C.A","5");
INSERT INTO `center_course`  VALUES ( "10","PGDCA","5");
INSERT INTO `center_course`  VALUES ( "11","DOEACC A  Level","5");
INSERT INTO `center_course`  VALUES ( "12","Ph.D.","5");
INSERT INTO `center_course`  VALUES ( "13","M.A./M.Sc. in Geography","6");
INSERT INTO `center_course`  VALUES ( "14","Ph.D.","6");
INSERT INTO `center_course`  VALUES ( "15","M.A. in Mass Communication","7");
INSERT INTO `center_course`  VALUES ( "16","PG Diploma in Journalism and Mass Communication","7");
INSERT INTO `center_course`  VALUES ( "17","L.L.M.","8");
INSERT INTO `center_course`  VALUES ( "18","5 Year Integrated B.A.L.L.B.","8");
INSERT INTO `center_course`  VALUES ( "19","M.A. in Hindi","9");
INSERT INTO `center_course`  VALUES ( "20","Diploma Course in Tai Language (DCTL)","9");
INSERT INTO `center_course`  VALUES ( "21","Certificate Course in Chinese Language (CCCL)","9");
INSERT INTO `center_course`  VALUES ( "22","Three Months Certificate Course in Spoken Tai (3MCCST)","9");
INSERT INTO `center_course`  VALUES ( "23","Short Term Thai Course","9");
INSERT INTO `center_course`  VALUES ( "24","Master of Library and Information Science (M.L.I.Sc.)","10");
INSERT INTO `center_course`  VALUES ( "25","Bachelor of Library and Information Science (B.L.I.Sc.)","10");
INSERT INTO `center_course`  VALUES ( "26","M.B.A. (Full Time)","11");
INSERT INTO `center_course`  VALUES ( "27","M.B.A. (Part Time)","11");
INSERT INTO `center_course`  VALUES ( "28","BBA","11");
INSERT INTO `center_course`  VALUES ( "29","Post Graduate Diploma in Tourism Management (PGDTM)","11");
INSERT INTO `center_course`  VALUES ( "30","Ph.D.","11");
INSERT INTO `center_course`  VALUES ( "31","Advanced Post Graduate Diploma in Nanoscience and Composite Materials","12");
INSERT INTO `center_course`  VALUES ( "32","M.A. in Performing Arts (Sattriya Dance)","13");
INSERT INTO `center_course`  VALUES ( "33","M.A. in Performing Arts (Theatre Art)","13");
INSERT INTO `center_course`  VALUES ( "34","M.A. in Performing Arts (Vocal Music)","13");
INSERT INTO `center_course`  VALUES ( "35","B.A. in Performing Arts","13");
INSERT INTO `center_course`  VALUES ( "36","Ph.D.","14");
INSERT INTO `center_course`  VALUES ( "37","Master of Physical Education (M.P.Ed.)","15");
INSERT INTO `center_course`  VALUES ( "38","Bachelor of Physical Education (B.P.Ed.)","15");
INSERT INTO `center_course`  VALUES ( "39","Post Graduate Diploma in Rural Development","16");
INSERT INTO `center_course`  VALUES ( "40","Master of Social Work","17");
INSERT INTO `center_course`  VALUES ( "41","Post Graduate Diploma in Tea Technology and Plantation Management (PGDTTPM)","18");
INSERT INTO `center_course`  VALUES ( "42","Post Graduate Certificate Course in Women’s Studies (PGCCWS)","19");
INSERT INTO `center_course`  VALUES ( "43","Ph.D.","19");


--
-- Tabel structure for table `course`
--
DROP TABLE  IF EXISTS `course`;
CREATE TABLE `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(500) NOT NULL,
  `dept_code` int(11) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=MyISAM AUTO_INCREMENT=79 DEFAULT CHARSET=latin1 COMMENT='department_courses';

INSERT INTO `course`  VALUES ( "2","Ph.D.","1");
INSERT INTO `course`  VALUES ( "3","M.Sc. Applied Geology","2");
INSERT INTO `course`  VALUES ( "4","M.Tech. in Exploration Geophysics","2");
INSERT INTO `course`  VALUES ( "5","M.Tech. in Petroleum Geology","2");
INSERT INTO `course`  VALUES ( "6","Ph.D.","2");
INSERT INTO `course`  VALUES ( "8","M. Phil. in Assamese","3");
INSERT INTO `course`  VALUES ( "9","Ph.D.","3");
INSERT INTO `course`  VALUES ( "10","M.Sc. in Chemistry","4");
INSERT INTO `course`  VALUES ( "11","M.Phil. in Chemistry","4");
INSERT INTO `course`  VALUES ( "12","Ph.D.","4");
INSERT INTO `course`  VALUES ( "13","M.Com. ","5");
INSERT INTO `course`  VALUES ( "14","Post Graduate Diploma in Finance (PGDF)","5");
INSERT INTO `course`  VALUES ( "15","Post Graduate Diploma in Marketing (PGDM)","5");
INSERT INTO `course`  VALUES ( "16","M. Phil. In Commerce","5");
INSERT INTO `course`  VALUES ( "17","Ph.D.","5");
INSERT INTO `course`  VALUES ( "18","M.A. in Economics","6");
INSERT INTO `course`  VALUES ( "19","M. Phil. in Economics","6");
INSERT INTO `course`  VALUES ( "20","Ph.D.","6");
INSERT INTO `course`  VALUES ( "21","M.A. in Education","7");
INSERT INTO `course`  VALUES ( "22","M.Ed.","7");
INSERT INTO `course`  VALUES ( "23","B.Ed.","7");
INSERT INTO `course`  VALUES ( "24","M. Phil. in Education","7");
INSERT INTO `course`  VALUES ( "25","Ph.D.","7");
INSERT INTO `course`  VALUES ( "26","M.A. in English","8");
INSERT INTO `course`  VALUES ( "27","M. Phil. in English","8");
INSERT INTO `course`  VALUES ( "28","Ph.D.","8");
INSERT INTO `course`  VALUES ( "29","M.A. in History","9");
INSERT INTO `course`  VALUES ( "30","M. Phil. in History","9");
INSERT INTO `course`  VALUES ( "31","Ph.D.","9");
INSERT INTO `course`  VALUES ( "32","M.Sc. in Life Sciences (Botany/Zoology)","10");
INSERT INTO `course`  VALUES ( "33","Ph.D. ","10");
INSERT INTO `course`  VALUES ( "34","M.A./M.Sc. in Mathematics","11");
INSERT INTO `course`  VALUES ( "35","M. Phil. in Mathematics","11");
INSERT INTO `course`  VALUES ( "36","Ph.D.","11");
INSERT INTO `course`  VALUES ( "37","M. Tech. in Petroleum Exploration and Production","12");
INSERT INTO `course`  VALUES ( "38","Ph.D.","12");
INSERT INTO `course`  VALUES ( "39","M.Pharm.","13");
INSERT INTO `course`  VALUES ( "40","B.Pharm.","13");
INSERT INTO `course`  VALUES ( "41","Ph.D.","13");
INSERT INTO `course`  VALUES ( "42","M.Sc. in Physics","14");
INSERT INTO `course`  VALUES ( "43","5 Years Integrated M.Sc. in Physics","14");
INSERT INTO `course`  VALUES ( "44","M.Phil. in Physics","14");
INSERT INTO `course`  VALUES ( "45","Ph.D.","14");
INSERT INTO `course`  VALUES ( "46","M.A. in Political Science","15");
INSERT INTO `course`  VALUES ( "47","M.Phil. in Political Science","15");
INSERT INTO `course`  VALUES ( "48","Ph.D.","15");
INSERT INTO `course`  VALUES ( "49","M.A. in Sociology","16");
INSERT INTO `course`  VALUES ( "50","M.Phil. in Sociology","16");
INSERT INTO `course`  VALUES ( "51","M.A./M.Sc. in Statistics","17");
INSERT INTO `course`  VALUES ( "52","Post Graduate Diploma in Statistical Techniques & Computation (PGDSTC)","17");
INSERT INTO `course`  VALUES ( "53","Post Graduate Diploma in Actuarial Sciences (PGDAS)","17");
INSERT INTO `course`  VALUES ( "54","Certificate Course in Statistics (CCS)","17");
INSERT INTO `course`  VALUES ( "56","Ph.D.","17");
INSERT INTO `course`  VALUES ( "78","Sad","4");
INSERT INTO `course`  VALUES ( "76","B.Tech In CSE","22");


--
-- Tabel structure for table `department`
--
DROP TABLE  IF EXISTS `department`;
CREATE TABLE `department` (
  `dept_code` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(200) NOT NULL,
  `sf_code` varchar(200) NOT NULL,
  PRIMARY KEY (`dept_code`),
  UNIQUE KEY `dept_name` (`dept_name`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `department`  VALUES ( "1","Dept. of Anthropology","ANT");
INSERT INTO `department`  VALUES ( "2","Dept. of Applied Geology","APG");
INSERT INTO `department`  VALUES ( "3","Dept. of Assamese","ASS");
INSERT INTO `department`  VALUES ( "4","Dept. Of Chemistry","CHE");
INSERT INTO `department`  VALUES ( "5","Dept. of Commerce","COM");
INSERT INTO `department`  VALUES ( "6","Dept. of Economics","ECO");
INSERT INTO `department`  VALUES ( "7","Dept. of Education","EDU");
INSERT INTO `department`  VALUES ( "9","Dept. of History","HIS");
INSERT INTO `department`  VALUES ( "12","Dept. of Petroleum Technology","PET");
INSERT INTO `department`  VALUES ( "25","Dept. Of Life Sciences","DLS");
INSERT INTO `department`  VALUES ( "16","Dept. of Sociology","SOC");
INSERT INTO `department`  VALUES ( "17","Dept. of Statistics","STA");
INSERT INTO `department`  VALUES ( "23","Department Of High Tech Sciences","HTS");
INSERT INTO `department`  VALUES ( "24","Department Of Telemetry","DTM");


--
-- Tabel structure for table `fee_category`
--
DROP TABLE  IF EXISTS `fee_category`;
CREATE TABLE `fee_category` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(256) NOT NULL,
  PRIMARY KEY (`fee_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `fee_category`  VALUES ( "1","Sponsored");
INSERT INTO `fee_category`  VALUES ( "2","Endowment");
INSERT INTO `fee_category`  VALUES ( "3","General");


--
-- Tabel structure for table `g_modules`
--
DROP TABLE  IF EXISTS `g_modules`;
CREATE TABLE `g_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `display_status` varchar(10) NOT NULL COMMENT '0-choosy 1-all',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `g_modules`  VALUES ( "1","Library Books Management","0");
INSERT INTO `g_modules`  VALUES ( "2","Library Member Management","0");
INSERT INTO `g_modules`  VALUES ( "3","Book Issue and Receipt Management","0");


--
-- Tabel structure for table `g_operator_access_modules`
--
DROP TABLE  IF EXISTS `g_operator_access_modules`;
CREATE TABLE `g_operator_access_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operator_id` varchar(200) NOT NULL,
  `module_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `g_settings`
--
DROP TABLE  IF EXISTS `g_settings`;
CREATE TABLE `g_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) DEFAULT NULL COMMENT 'school name',
  `short_form` varchar(200) NOT NULL,
  `crm_helpdesk_email` varchar(255) NOT NULL COMMENT 'school email',
  `crm_settings_last_modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP COMMENT 'school settings modified on',
  `crm_description` text COMMENT 'school description',
  `crm_logo` varchar(255) DEFAULT NULL COMMENT 'school logo',
  `crm_helpline_number` varchar(20) DEFAULT NULL COMMENT 'school number 1',
  `crm_helpline_number_second` varchar(30) DEFAULT NULL COMMENT 'school number 2',
  `crm_status` varchar(4) NOT NULL COMMENT '0-active, 1-inactive',
  `company_estd_on` varchar(20) DEFAULT NULL COMMENT 'school estd on',
  `web` varchar(255) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `country` varchar(40) NOT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pocode` varchar(10) DEFAULT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='admin_access';

INSERT INTO `g_settings`  VALUES ( "1","Dibrugarh University","DUCP","info@lms.co.in","2014-06-24 16:27:33","An admin panel designed for Dibrugarh University for maintaining and planning the university related works so as to optimise the university growth by automating the time consuming paper works in the office.","logo//favicon.png","2410392","2410564","0","2011","http://www.du.com","Guwahati","INDIA","Assam","781020","National Highway 37, Dibrugarh, Assam 786004
Dibrugarh University");


--
-- Tabel structure for table `g_users`
--
DROP TABLE  IF EXISTS `g_users`;
CREATE TABLE `g_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dept_code` varchar(50) NOT NULL COMMENT 'dept or centre code',
  `user_type` varchar(200) NOT NULL COMMENT 'admin/operator',
  `status` varchar(50) NOT NULL COMMENT 'A-Available N-Not Available',
  `branch_type` varchar(50) NOT NULL COMMENT 'center/dept',
  `user_entered_on` varchar(255) NOT NULL,
  `user_login_ip` varchar(255) NOT NULL,
  `user_logged_in` varchar(10) NOT NULL COMMENT 'yes/no',
  `login_time` varchar(255) NOT NULL,
  `user_info_modified_on` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `g_users`  VALUES ( "1","admin@du","admin@du","","admin","A","admin","","169.254.64.203","yes","Friday 27th June 2014 6.37AM","2014-06-26 18:06:58");
INSERT INTO `g_users`  VALUES ( "16","demos","demos","3","operator","A","dept","","169.254.64.203","no","Friday 27th June 2014 6.18AM","2014-06-26 17:48:02");
INSERT INTO `g_users`  VALUES ( "17","cen","cen","4","operator","A","center","","169.254.64.203","no","Friday 27th June 2014 6.18AM","2014-06-26 18:06:07");
INSERT INTO `g_users`  VALUES ( "19","women","women","19","operator","A","center","","169.254.64.203","yes","Friday 27th June 2014 4.47AM","2014-06-26 16:19:38");


--
-- Tabel structure for table `month_codes`
--
DROP TABLE  IF EXISTS `month_codes`;
CREATE TABLE `month_codes` (
  `month_id` int(11) NOT NULL AUTO_INCREMENT,
  `month_name` varchar(50) NOT NULL,
  PRIMARY KEY (`month_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `month_codes`  VALUES ( "1","January");
INSERT INTO `month_codes`  VALUES ( "2","February");
INSERT INTO `month_codes`  VALUES ( "3","March");
INSERT INTO `month_codes`  VALUES ( "4","April");
INSERT INTO `month_codes`  VALUES ( "5","May");
INSERT INTO `month_codes`  VALUES ( "6","June");
INSERT INTO `month_codes`  VALUES ( "7","July");
INSERT INTO `month_codes`  VALUES ( "8","August");
INSERT INTO `month_codes`  VALUES ( "9","September");
INSERT INTO `month_codes`  VALUES ( "10","October");
INSERT INTO `month_codes`  VALUES ( "11","November");
INSERT INTO `month_codes`  VALUES ( "12","December");


--
-- Tabel structure for table `semester`
--
DROP TABLE  IF EXISTS `semester`;
CREATE TABLE `semester` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `semester` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `semester`  VALUES ( "1","1st Semester");
INSERT INTO `semester`  VALUES ( "2","2nd Semester");
INSERT INTO `semester`  VALUES ( "3","3rd Semester");
INSERT INTO `semester`  VALUES ( "4","4th Semester");
INSERT INTO `semester`  VALUES ( "5","5th Semester");
INSERT INTO `semester`  VALUES ( "6","6th Semester");
INSERT INTO `semester`  VALUES ( "7","7th Semester");
INSERT INTO `semester`  VALUES ( "8","8th Semester");
INSERT INTO `semester`  VALUES ( "9","9th Semester");
INSERT INTO `semester`  VALUES ( "10","10th Semester");


--
-- Tabel structure for table `student_details`
--
DROP TABLE  IF EXISTS `student_details`;
CREATE TABLE `student_details` (
  `sl` int(10) NOT NULL AUTO_INCREMENT,
  `dept_center_code` varchar(20) NOT NULL,
  `dept_center_course_code` varchar(20) NOT NULL,
  `center_code` varchar(40) NOT NULL,
  `semester_code` varchar(10) NOT NULL,
  `year_of_admission` int(4) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `registration_no` varchar(200) NOT NULL,
  `roll_no` varchar(200) NOT NULL,
  `fathers_name` varchar(255) NOT NULL,
  `mothers_name` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `sex` varchar(50) NOT NULL,
  `community` varchar(255) NOT NULL,
  `region` varchar(255) NOT NULL,
  `fee_category` varchar(255) NOT NULL,
  `mb_no` varchar(50) NOT NULL,
  `fee_paid_upto_semester_code` int(11) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `student_id` varchar(200) NOT NULL,
  `belongs_to_center_dept` varchar(50) NOT NULL COMMENT 'center/dept',
  PRIMARY KEY (`sl`),
  UNIQUE KEY `registration_no` (`registration_no`),
  UNIQUE KEY `registration_no_2` (`registration_no`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;



SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
